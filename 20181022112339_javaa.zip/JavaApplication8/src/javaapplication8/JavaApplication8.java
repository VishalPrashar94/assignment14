/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication8;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author 1794421
 */
public class JavaApplication8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int noOfElements, noToSearch;
        int index = 0;
        boolean elementFound = false;
         
        Scanner s = new Scanner(System.in);
        Random randomObj = new Random();
        System.out.print("How many elements ? ");
        noOfElements = s.nextInt();
        int[] array = new int[noOfElements];
        System.out.println("Random numbers are : ");
        for (int i = 0; i <noOfElements  ; i++) {
            array[i] = randomObj.nextInt(1000);
            System.out.println((i+1) + ": " +array[i]);
            
        }
        System.out.println("Which number to search ? ");
        noToSearch = s.nextInt();
        for (int i = 0; i < noOfElements; i++) {
            if(array[i] == noToSearch){
                index = i;
                elementFound = true;
            }
        }
        if(elementFound == true){
            System.out.println("Element found at index : " + index);
        }
        else{
            System.out.println("element not found");
        }
        System.out.println("");
        System.out.println("End of this Assignment");
    }
    
}
